﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Data.SqlClient;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "UserDB Application";
        }
        //Database
        OleDbConnection conn;
        OleDbCommand cmd;

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Users\\gopal\\OneDrive\\Documents\\db1.mdb");
            cmd = new OleDbCommand();
            cmd.Connection = conn;

            //DISPLAY DATA ON LOAD
            displayData();
        }

        private void txt_name_TextChanged(object sender, EventArgs e)
        {
        }

        private void txt_city_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
        //INPUT NAME VALIDATION
        private bool checkname(string str, string str_who)
        {
            switch (str_who)
            {
                case "name": 
                                if (str.Length == 0)
                                {
                                    lbl_name_alert.Visible = true;
                                    return false;
                                }
                                break;
                case "age":
                                if (str.Length == 0)
                                {
                                    lbl_age_alert.Visible = true;
                                    return false;
                                }
                                break;
                case "city":
                                if (str.Length == 0)
                                {
                                    lbl_city_alert.Visible = true;
                                    return false;
                                }
                                break;
                case "id":
                                if (str.Length == 0)
                                {
                                    lbl_id_alert.Visible = true;
                                    return false;
                                }
                                break;

            }
            return true; 
        }
        //INSERT
        private void btn_submit_Click(object sender, EventArgs e)
        {
            lbl_NoUsersFound.Visible = false;
            clearAlertLabels();
            string str_name = checkname(txt_name.Text,"name") ? txt_name.Text : null;
            string str_age = checkname(txt_age.Text.ToString(),"age") ? txt_age.Text.ToString() : null;
            string str_city = checkname(txt_city.Text, "city") ? txt_city.Text : null;

            if (str_name != null && str_city != null && str_age != null)
            {
                string qry = "insert into users(name,age,city) values('"+ str_name +"',"+ str_age +",'"+ str_city +"')";
                //lbl_qry.Text = qry;
                //lbl_qry.Visible = true;

                //qry = "select * from users";
                cmd.CommandText = qry;
            
                conn.Open();
                cmd.ExecuteNonQuery();
                clearData();
                conn.Close();
            }
            displayData();
        }

        //CLEAR INPUTS/TEXTBOX
        public void clearData()
        {
            txt_name.Clear();
            txt_age.Clear();
            txt_city.Text = "";
            txt_id.Clear();
            clearAlertLabels();
        }
        public void clearAlertLabels()
        {
            lbl_age_alert.Visible = lbl_city_alert.Visible = lbl_name_alert.Visible = lbl_id_alert.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            displayData();
        }

        //DISPLAY USERS
        private void displayData()
        {
            lbl_NoUsersFound.Visible = false;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from users";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            tbl_records.DataSource = dt;
            conn.Close();
        }

        //DELETE USER
        private void btn_delete_Click(object sender, EventArgs e)
        {
            lbl_NoUsersFound.Visible = false;
            clearAlertLabels();
            string str_id = checkname(txt_id.Text, "id") ? txt_id.Text : null;
            if (str_id != null) 
            {
                string qry = "DELETE * FROM USERS WHERE id=" + str_id;
                cmd.CommandText = qry;
                conn.Open();
                //cmd.ExecuteNonQuery();
                int rows = cmd.ExecuteNonQuery();
                if (rows == 0)
                {
                    lbl_NoUsersFound.Visible = true;
                }
                clearData();
                conn.Close();
            }
            displayData();
        }

        //FIND USER
        private void btn_search_Click(object sender, EventArgs e)
        {
            lbl_NoUsersFound.Visible = false;
            clearAlertLabels();

            string str_id = checkname(txt_id.Text, "id") ? txt_id.Text : null;
            if (str_id != null)
            {
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from users where id=" + txt_id.Text.ToString();
                //cmd.ExecuteNonQuery();
                int rows = cmd.ExecuteNonQuery();
                if (rows == 0)
                {
                    lbl_NoUsersFound.Visible = true;
                }
                else
                {
                    DataTable dt = new DataTable();
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    da.Fill(dt);
                    tbl_records.DataSource = dt;
                }
                conn.Close();
            }
        }

        //UPDATE
        private void btn_update_Click(object sender, EventArgs e)
        {
            lbl_NoUsersFound.Visible = false;
            clearAlertLabels();
            string str_id = checkname(txt_id.Text, "id") ? txt_id.Text : null;
            string str_name = checkname(txt_name.Text,"name") ? txt_name.Text : null;
            string str_age = checkname(txt_age.Text.ToString(),"age") ? txt_age.Text.ToString() : null;
            string str_city = checkname(txt_city.Text, "city") ? txt_city.Text : null;

            if (str_name != null && str_city != null && str_age != null && str_id != null)
            {
                string qry = "UPDATE users SET name='" + str_name + "', age=" + str_age + ", city='" + str_city + "' WHERE id=" + str_id;
                cmd.CommandText = qry;
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows == 0)
                {
                    lbl_NoUsersFound.Visible = true;
                }
                clearData();
                conn.Close();
            }
            displayData();
        }
    }
}
